(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
if (Meteor.isClient) {
  Template.soon.greeting = function() {
    return "Welcome to dynamoshop";
  };
}

})();
