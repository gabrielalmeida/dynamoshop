(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

(function () {

///////////////////////////////////////////////////////////////////////////////////
//                                                                               //
// packages/preserve-inputs/deprecated.js                                        //
//                                                                               //
///////////////////////////////////////////////////////////////////////////////////
                                                                                 //
console.log("The 'preserve-inputs' package is now unnecessary and deprecated."); // 1
                                                                                 // 2
///////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['preserve-inputs'] = {};

})();
