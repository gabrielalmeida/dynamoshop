(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var HTML;

(function () {

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                      //
// packages/htmljs/utils.js                                                                             //
//                                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                        //
                                                                                                        // 1
HTML = {};                                                                                              // 2
                                                                                                        // 3
HTML.isNully = function (node) {                                                                        // 4
  if (node == null)                                                                                     // 5
    // null or undefined                                                                                // 6
    return true;                                                                                        // 7
                                                                                                        // 8
  if (node instanceof Array) {                                                                          // 9
    // is it an empty array or an array of all nully items?                                             // 10
    for (var i = 0; i < node.length; i++)                                                               // 11
      if (! HTML.isNully(node[i]))                                                                      // 12
        return false;                                                                                   // 13
    return true;                                                                                        // 14
  }                                                                                                     // 15
                                                                                                        // 16
  return false;                                                                                         // 17
};                                                                                                      // 18
                                                                                                        // 19
HTML.escapeData = function (str) {                                                                      // 20
  // string; escape the two special chars in HTML data and RCDATA                                       // 21
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;');                                              // 22
};                                                                                                      // 23
                                                                                                        // 24
                                                                                                        // 25
// The HTML spec and the DOM API (in particular `setAttribute`) have different                          // 26
// definitions of what characters are legal in an attribute.  The HTML                                  // 27
// parser is extremely permissive (allowing, for example, `<a %=%>`), while                             // 28
// `setAttribute` seems to use something like the XML grammar for names (and                            // 29
// throws an error if a name is invalid, making that attribute unsettable).                             // 30
// If we knew exactly what grammar browsers used for `setAttribute`, we could                           // 31
// include various Unicode ranges in what's legal.  For now, allow ASCII chars                          // 32
// that are known to be valid XML, valid HTML, and settable via `setAttribute`:                         // 33
//                                                                                                      // 34
// * Starts with `:`, `_`, `A-Z` or `a-z`                                                               // 35
// * Consists of any of those plus `-`, `.`, and `0-9`.                                                 // 36
//                                                                                                      // 37
// See <http://www.w3.org/TR/REC-xml/#NT-Name> and                                                      // 38
// <http://dev.w3.org/html5/markup/syntax.html#syntax-attributes>.                                      // 39
HTML.isValidAttributeName = function (name) {                                                           // 40
  return /^[:_A-Za-z][:_A-Za-z0-9.\-]*/.test(name);                                                     // 41
};                                                                                                      // 42
                                                                                                        // 43
//////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                      //
// packages/htmljs/html.js                                                                              //
//                                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                        //
                                                                                                        // 1
// Tag instances are `instanceof HTML.Tag`.                                                             // 2
//                                                                                                      // 3
// Tag objects should be considered immutable.                                                          // 4
//                                                                                                      // 5
// This is a private constructor of an abstract class; don't call it.                                   // 6
HTML.Tag = function () {};                                                                              // 7
HTML.Tag.prototype.tagName = ''; // this will be set per Tag subclass                                   // 8
HTML.Tag.prototype.attrs = null;                                                                        // 9
HTML.Tag.prototype.children = Object.freeze ? Object.freeze([]) : [];                                   // 10
                                                                                                        // 11
// Given "p", create and assign `HTML.P` if it doesn't already exist.                                   // 12
// Then return it.  `tagName` must have proper case (usually all lowercase).                            // 13
HTML.getTag = function (tagName) {                                                                      // 14
  var symbolName = HTML.getSymbolName(tagName);                                                         // 15
  if (symbolName === tagName) // all-caps tagName                                                       // 16
    throw new Error("Use the lowercase or camelCase form of '" + tagName + "' here");                   // 17
                                                                                                        // 18
  if (! HTML[symbolName])                                                                               // 19
    HTML[symbolName] = makeTagConstructor(tagName);                                                     // 20
                                                                                                        // 21
  return HTML[symbolName];                                                                              // 22
};                                                                                                      // 23
                                                                                                        // 24
// Given "p", make sure `HTML.P` exists.  `tagName` must have proper case                               // 25
// (usually all lowercase).                                                                             // 26
HTML.ensureTag = function (tagName) {                                                                   // 27
  HTML.getTag(tagName); // don't return it                                                              // 28
};                                                                                                      // 29
                                                                                                        // 30
// Given "p" create the function `HTML.P`.                                                              // 31
var makeTagConstructor = function (tagName) {                                                           // 32
  // HTMLTag is the per-tagName constructor of a HTML.Tag subclass                                      // 33
  var HTMLTag = function HTMLTag(/*arguments*/) {                                                       // 34
    // Work with or without `new`.  If not called with `new`,                                           // 35
    // perform instantiation by recursively calling this constructor.                                   // 36
    // We can't pass varargs, so pass no args.                                                          // 37
    var instance = (this instanceof HTML.Tag) ? this : new HTMLTag;                                     // 38
                                                                                                        // 39
    var i = 0;                                                                                          // 40
    var attrs = arguments.length && arguments[0];                                                       // 41
    if (attrs && (typeof attrs === 'object') &&                                                         // 42
        (attrs.constructor === Object)) {                                                               // 43
      instance.attrs = attrs;                                                                           // 44
      i++;                                                                                              // 45
    }                                                                                                   // 46
                                                                                                        // 47
    // If no children, don't create an array at all, use the prototype's                                // 48
    // (frozen, empty) array.  This way we don't create an empty array                                  // 49
    // every time someone creates a tag without `new` and this constructor                              // 50
    // calls itself with no arguments (above).                                                          // 51
    if (i < arguments.length)                                                                           // 52
      instance.children = Array.prototype.slice.call(arguments, i);                                     // 53
                                                                                                        // 54
    return instance;                                                                                    // 55
  };                                                                                                    // 56
  HTMLTag.prototype = new HTML.Tag;                                                                     // 57
  HTMLTag.prototype.constructor = HTMLTag;                                                              // 58
  HTMLTag.prototype.tagName = tagName;                                                                  // 59
                                                                                                        // 60
  return HTMLTag;                                                                                       // 61
};                                                                                                      // 62
                                                                                                        // 63
var CharRef = HTML.CharRef = function (attrs) {                                                         // 64
  if (! (this instanceof CharRef))                                                                      // 65
    // called without `new`                                                                             // 66
    return new CharRef(attrs);                                                                          // 67
                                                                                                        // 68
  if (! (attrs && attrs.html && attrs.str))                                                             // 69
    throw new Error(                                                                                    // 70
      "HTML.CharRef must be constructed with ({html:..., str:...})");                                   // 71
                                                                                                        // 72
  this.html = attrs.html;                                                                               // 73
  this.str = attrs.str;                                                                                 // 74
};                                                                                                      // 75
                                                                                                        // 76
var Comment = HTML.Comment = function (value) {                                                         // 77
  if (! (this instanceof Comment))                                                                      // 78
    // called without `new`                                                                             // 79
    return new Comment(value);                                                                          // 80
                                                                                                        // 81
  if (typeof value !== 'string')                                                                        // 82
    throw new Error('HTML.Comment must be constructed with a string');                                  // 83
                                                                                                        // 84
  this.value = value;                                                                                   // 85
  // Kill illegal hyphens in comment value (no way to escape them in HTML)                              // 86
  this.sanitizedValue = value.replace(/^-|--+|-$/g, '');                                                // 87
};                                                                                                      // 88
                                                                                                        // 89
                                                                                                        // 90
//---------- KNOWN ELEMENTS                                                                             // 91
                                                                                                        // 92
// These lists of known elements are public.  You can use them, for example, to                         // 93
// write a helper that determines the proper case for an SVG element name.                              // 94
// Such helpers that may not be needed at runtime are not provided here.                                // 95
                                                                                                        // 96
HTML.knownElementNames = 'a abbr acronym address applet area b base basefont bdo big blockquote body br button caption center cite code col colgroup dd del dfn dir div dl dt em fieldset font form frame frameset h1 h2 h3 h4 h5 h6 head hr html i iframe img input ins isindex kbd label legend li link map menu meta noframes noscript object ol optgroup option p param pre q s samp script select small span strike strong style sub sup table tbody td textarea tfoot th thead title tr tt u ul var article aside audio bdi canvas command data datagrid datalist details embed eventsource figcaption figure footer header hgroup keygen mark meter nav output progress ruby rp rt section source summary time track video wbr'.split(' ');
                                                                                                        // 98
// omitted because also an HTML element: "a"                                                            // 99
HTML.knownSVGElementNames = 'altGlyph altGlyphDef altGlyphItem animate animateColor animateMotion animateTransform circle clipPath color-profile cursor defs desc ellipse feBlend feColorMatrix feComponentTransfer feComposite feConvolveMatrix feDiffuseLighting feDisplacementMap feDistantLight feFlood feFuncA feFuncB feFuncG feFuncR feGaussianBlur feImage feMerge feMergeNode feMorphology feOffset fePointLight feSpecularLighting feSpotLight feTile feTurbulence filter font font-face font-face-format font-face-name font-face-src font-face-uri foreignObject g glyph glyphRef hkern image line linearGradient marker mask metadata missing-glyph path pattern polygon polyline radialGradient rect script set stop style svg switch symbol text textPath title tref tspan use view vkern'.split(' ');
// Append SVG element names to list of known element names                                              // 101
HTML.knownElementNames = HTML.knownElementNames.concat(HTML.knownSVGElementNames);                      // 102
                                                                                                        // 103
HTML.voidElementNames = 'area base br col command embed hr img input keygen link meta param source track wbr'.split(' ');
                                                                                                        // 105
// Speed up search through lists of known elements by creating internal "sets"                          // 106
// of strings.                                                                                          // 107
var YES = {yes:true};                                                                                   // 108
var makeSet = function (array) {                                                                        // 109
  var set = {};                                                                                         // 110
  for (var i = 0; i < array.length; i++)                                                                // 111
    set[array[i]] = YES;                                                                                // 112
  return set;                                                                                           // 113
};                                                                                                      // 114
var voidElementSet = makeSet(HTML.voidElementNames);                                                    // 115
var knownElementSet = makeSet(HTML.knownElementNames);                                                  // 116
var knownSVGElementSet = makeSet(HTML.knownSVGElementNames);                                            // 117
                                                                                                        // 118
// Is the given element (in proper case) a known HTML element?                                          // 119
// This includes SVG elements.                                                                          // 120
HTML.isKnownElement = function (name) {                                                                 // 121
  return knownElementSet[name] === YES;                                                                 // 122
};                                                                                                      // 123
                                                                                                        // 124
// Is the given element (in proper case) an element with no end tag                                     // 125
// in HTML, like "br", "hr", or "input"?                                                                // 126
HTML.isVoidElement = function (name) {                                                                  // 127
  return voidElementSet[name] === YES;                                                                  // 128
};                                                                                                      // 129
                                                                                                        // 130
// Is the given element (in proper case) a known SVG element?                                           // 131
HTML.isKnownSVGElement = function (name) {                                                              // 132
  return knownSVGElementSet[name] === YES;                                                              // 133
};                                                                                                      // 134
                                                                                                        // 135
// For code generators, is a particular tag (in proper case) guaranteed                                 // 136
// to be available on the HTML object (under the name returned by                                       // 137
// getSymbolName)?                                                                                      // 138
HTML.isTagEnsured = function (t) {                                                                      // 139
  return HTML.isKnownElement(t);                                                                        // 140
};                                                                                                      // 141
                                                                                                        // 142
// For code generators, take a tagName like "p" and return an uppercase                                 // 143
// symbol name like "P" which is available on the "HTML" object for                                     // 144
// known elements or after calling getTag or ensureTag.                                                 // 145
HTML.getSymbolName = function (tagName) {                                                               // 146
  // "foo-bar" -> "FOO_BAR"                                                                             // 147
  return tagName.toUpperCase().replace(/-/g, '_');                                                      // 148
};                                                                                                      // 149
                                                                                                        // 150
// Ensure tags for all known elements                                                                   // 151
for (var i = 0; i < HTML.knownElementNames.length; i++)                                                 // 152
  HTML.ensureTag(HTML.knownElementNames[i]);                                                            // 153
                                                                                                        // 154
////////////////////////////////////////////////////////////////////////////////                        // 155
                                                                                                        // 156
// Call all functions and instantiate all components, when fine-grained                                 // 157
// reactivity is not needed (for example, in attributes).                                               // 158
HTML.evaluate = function (node, parentComponent) {                                                      // 159
  if (node == null) {                                                                                   // 160
    return node;                                                                                        // 161
  } else if (typeof node === 'function') {                                                              // 162
    return HTML.evaluate(node(), parentComponent);                                                      // 163
  } else if (node instanceof Array) {                                                                   // 164
    var result = [];                                                                                    // 165
    for (var i = 0; i < node.length; i++)                                                               // 166
      result.push(HTML.evaluate(node[i], parentComponent));                                             // 167
    return result;                                                                                      // 168
  } else if (typeof node.instantiate === 'function') {                                                  // 169
    // component                                                                                        // 170
    var instance = node.instantiate(parentComponent || null);                                           // 171
    var content = instance.render('STATIC');                                                            // 172
    return HTML.evaluate(content, instance);                                                            // 173
  }  else if (node instanceof HTML.Tag) {                                                               // 174
    var newChildren = [];                                                                               // 175
    for (var i = 0; i < node.children.length; i++)                                                      // 176
      newChildren.push(HTML.evaluate(node.children[i], parentComponent));                               // 177
    var newTag = HTML.getTag(node.tagName).apply(null, newChildren);                                    // 178
    newTag.attrs = {};                                                                                  // 179
    for (var k in node.attrs)                                                                           // 180
      newTag.attrs[k] = HTML.evaluate(node.attrs[k], parentComponent);                                  // 181
    return newTag;                                                                                      // 182
  } else {                                                                                              // 183
    return node;                                                                                        // 184
  }                                                                                                     // 185
};                                                                                                      // 186
                                                                                                        // 187
var extendAttrs = function (tgt, src, parentComponent) {                                                // 188
  for (var k in src) {                                                                                  // 189
    if (k === '$dynamic')                                                                               // 190
      continue;                                                                                         // 191
    if (! HTML.isValidAttributeName(k))                                                                 // 192
      throw new Error("Illegal HTML attribute name: " + k);                                             // 193
    var value = HTML.evaluate(src[k], parentComponent);                                                 // 194
    if (! HTML.isNully(value))                                                                          // 195
      tgt[k] = value;                                                                                   // 196
  }                                                                                                     // 197
};                                                                                                      // 198
                                                                                                        // 199
// Process the `attrs.$dynamic` directive, if present, returning the final                              // 200
// attributes dictionary.  The value of `attrs.$dynamic` must be an array                               // 201
// of attributes dictionaries or functions returning attribute dictionaries.                            // 202
// These attributes are used to extend `attrs` as long as they are non-nully.                           // 203
// All attributes are "evaluated," calling functions and instantiating                                  // 204
// components.                                                                                          // 205
HTML.evaluateAttributes = function (attrs, parentComponent) {                                           // 206
  if (! attrs)                                                                                          // 207
    return attrs;                                                                                       // 208
                                                                                                        // 209
  var result = {};                                                                                      // 210
  extendAttrs(result, attrs, parentComponent);                                                          // 211
                                                                                                        // 212
  if ('$dynamic' in attrs) {                                                                            // 213
    if (! (attrs.$dynamic instanceof Array))                                                            // 214
      throw new Error("$dynamic must be an array");                                                     // 215
    // iterate over attrs.$dynamic, calling each element if it                                          // 216
    // is a function and then using it to extend `result`.                                              // 217
    var dynamics = attrs.$dynamic;                                                                      // 218
    for (var i = 0; i < dynamics.length; i++) {                                                         // 219
      var moreAttrs = dynamics[i];                                                                      // 220
      if (typeof moreAttrs === 'function')                                                              // 221
        moreAttrs = moreAttrs();                                                                        // 222
      extendAttrs(result, moreAttrs, parentComponent);                                                  // 223
    }                                                                                                   // 224
  }                                                                                                     // 225
                                                                                                        // 226
  return result;                                                                                        // 227
};                                                                                                      // 228
                                                                                                        // 229
HTML.Tag.prototype.evaluateAttributes = function (parentComponent) {                                    // 230
  return HTML.evaluateAttributes(this.attrs, parentComponent);                                          // 231
};                                                                                                      // 232
                                                                                                        // 233
HTML.Raw = function (value) {                                                                           // 234
  if (! (this instanceof HTML.Raw))                                                                     // 235
    // called without `new`                                                                             // 236
    return new HTML.Raw(value);                                                                         // 237
                                                                                                        // 238
  if (typeof value !== 'string')                                                                        // 239
    throw new Error('HTML.Raw must be constructed with a string');                                      // 240
                                                                                                        // 241
  this.value = value;                                                                                   // 242
};                                                                                                      // 243
                                                                                                        // 244
HTML.EmitCode = function (value) {                                                                      // 245
  if (! (this instanceof HTML.EmitCode))                                                                // 246
    // called without `new`                                                                             // 247
    return new HTML.EmitCode(value);                                                                    // 248
                                                                                                        // 249
  if (typeof value !== 'string')                                                                        // 250
    throw new Error('HTML.EmitCode must be constructed with a string');                                 // 251
                                                                                                        // 252
  this.value = value;                                                                                   // 253
};                                                                                                      // 254
                                                                                                        // 255
//////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                      //
// packages/htmljs/tohtml.js                                                                            //
//                                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                        //
                                                                                                        // 1
HTML.toHTML = function (node, parentComponent) {                                                        // 2
  if (node == null) {                                                                                   // 3
    // null or undefined                                                                                // 4
    return '';                                                                                          // 5
  } else if ((typeof node === 'string') || (typeof node === 'boolean') || (typeof node === 'number')) { // 6
    // string; escape special chars                                                                     // 7
    return HTML.escapeData(String(node));                                                               // 8
  } else if (node instanceof Array) {                                                                   // 9
    // array                                                                                            // 10
    var parts = [];                                                                                     // 11
    for (var i = 0; i < node.length; i++)                                                               // 12
      parts.push(HTML.toHTML(node[i], parentComponent));                                                // 13
    return parts.join('');                                                                              // 14
  } else if (typeof node.instantiate === 'function') {                                                  // 15
    // component                                                                                        // 16
    var instance = node.instantiate(parentComponent || null);                                           // 17
    var content = instance.render('STATIC');                                                            // 18
    // recurse with a new value for parentComponent                                                     // 19
    return HTML.toHTML(content, instance);                                                              // 20
  } else if (typeof node === 'function') {                                                              // 21
    return HTML.toHTML(node(), parentComponent);                                                        // 22
  } else if (node.toHTML) {                                                                             // 23
    // Tag or something else                                                                            // 24
    return node.toHTML(parentComponent);                                                                // 25
  } else {                                                                                              // 26
    throw new Error("Expected tag, string, array, component, null, undefined, or " +                    // 27
                    "object with a toHTML method; found: " + node);                                     // 28
  }                                                                                                     // 29
};                                                                                                      // 30
                                                                                                        // 31
HTML.Comment.prototype.toHTML = function () {                                                           // 32
  return '<!--' + this.sanitizedValue + '-->';                                                          // 33
};                                                                                                      // 34
                                                                                                        // 35
HTML.CharRef.prototype.toHTML = function () {                                                           // 36
  return this.html;                                                                                     // 37
};                                                                                                      // 38
                                                                                                        // 39
HTML.Raw.prototype.toHTML = function () {                                                               // 40
  return this.value;                                                                                    // 41
};                                                                                                      // 42
                                                                                                        // 43
HTML.Tag.prototype.toHTML = function (parentComponent) {                                                // 44
  var attrStrs = [];                                                                                    // 45
  var attrs = this.evaluateAttributes(parentComponent);                                                 // 46
  if (attrs) {                                                                                          // 47
    for (var k in attrs) {                                                                              // 48
      var v = HTML.toText(attrs[k], HTML.TEXTMODE.ATTRIBUTE, parentComponent);                          // 49
      attrStrs.push(' ' + k + '="' + v + '"');                                                          // 50
    }                                                                                                   // 51
  }                                                                                                     // 52
                                                                                                        // 53
  var tagName = this.tagName;                                                                           // 54
  var startTag = '<' + tagName + attrStrs.join('') + '>';                                               // 55
                                                                                                        // 56
  var childStrs = [];                                                                                   // 57
  var content;                                                                                          // 58
  if (tagName === 'textarea') {                                                                         // 59
    for (var i = 0; i < this.children.length; i++)                                                      // 60
      childStrs.push(HTML.toText(this.children[i], HTML.TEXTMODE.RCDATA, parentComponent));             // 61
                                                                                                        // 62
    content = childStrs.join('');                                                                       // 63
    if (content.slice(0, 1) === '\n')                                                                   // 64
      // TEXTAREA will absorb a newline, so if we see one, add                                          // 65
      // another one.                                                                                   // 66
      content = '\n' + content;                                                                         // 67
                                                                                                        // 68
  } else {                                                                                              // 69
    for (var i = 0; i < this.children.length; i++)                                                      // 70
      childStrs.push(HTML.toHTML(this.children[i], parentComponent));                                   // 71
                                                                                                        // 72
    content = childStrs.join('');                                                                       // 73
  }                                                                                                     // 74
                                                                                                        // 75
  var result = startTag + content;                                                                      // 76
                                                                                                        // 77
  if (this.children.length || ! HTML.isVoidElement(tagName)) {                                          // 78
    // "Void" elements like BR are the only ones that don't get a close                                 // 79
    // tag in HTML5.  They shouldn't have contents, either, so we could                                 // 80
    // throw an error upon seeing contents here.                                                        // 81
    result += '</' + tagName + '>';                                                                     // 82
  }                                                                                                     // 83
                                                                                                        // 84
  return result;                                                                                        // 85
};                                                                                                      // 86
                                                                                                        // 87
HTML.TEXTMODE = {                                                                                       // 88
  ATTRIBUTE: 1,                                                                                         // 89
  RCDATA: 2,                                                                                            // 90
  STRING: 3                                                                                             // 91
};                                                                                                      // 92
                                                                                                        // 93
HTML.toText = function (node, textMode, parentComponent) {                                              // 94
  if (node == null) {                                                                                   // 95
    // null or undefined                                                                                // 96
    return '';                                                                                          // 97
  } else if ((typeof node === 'string') || (typeof node === 'boolean') || (typeof node === 'number')) { // 98
    node = String(node);                                                                                // 99
    // string                                                                                           // 100
    if (textMode === HTML.TEXTMODE.STRING) {                                                            // 101
      return node;                                                                                      // 102
    } else if (textMode === HTML.TEXTMODE.RCDATA) {                                                     // 103
      return HTML.escapeData(node);                                                                     // 104
    } else if (textMode === HTML.TEXTMODE.ATTRIBUTE) {                                                  // 105
      // escape `&` and `"` this time, not `&` and `<`                                                  // 106
      return node.replace(/&/g, '&amp;').replace(/"/g, '&quot;');                                       // 107
    } else {                                                                                            // 108
      throw new Error("Unknown TEXTMODE: " + textMode);                                                 // 109
    }                                                                                                   // 110
  } else if (node instanceof Array) {                                                                   // 111
    // array                                                                                            // 112
    var parts = [];                                                                                     // 113
    for (var i = 0; i < node.length; i++)                                                               // 114
      parts.push(HTML.toText(node[i], textMode, parentComponent));                                      // 115
    return parts.join('');                                                                              // 116
  } else if (typeof node === 'function') {                                                              // 117
    return HTML.toText(node(), textMode, parentComponent);                                              // 118
  } else if (typeof node.instantiate === 'function') {                                                  // 119
    // component                                                                                        // 120
    var instance = node.instantiate(parentComponent || null);                                           // 121
    var content = instance.render('STATIC');                                                            // 122
    return HTML.toText(content, textMode, instance);                                                    // 123
  } else if (node.toText) {                                                                             // 124
    // Something else                                                                                   // 125
    return node.toText(textMode, parentComponent);                                                      // 126
  } else {                                                                                              // 127
    throw new Error("Expected tag, string, array, component, null, undefined, or " +                    // 128
                    "object with a toText method; found: " + node);                                     // 129
  }                                                                                                     // 130
                                                                                                        // 131
};                                                                                                      // 132
                                                                                                        // 133
HTML.Raw.prototype.toText = function () {                                                               // 134
  return this.value;                                                                                    // 135
};                                                                                                      // 136
                                                                                                        // 137
// used when including templates within {{#markdown}}                                                   // 138
HTML.Tag.prototype.toText = function (textMode, parentComponent) {                                      // 139
  if (textMode === HTML.TEXTMODE.STRING)                                                                // 140
    // stringify the tag as HTML, then convert to text                                                  // 141
    return HTML.toText(this.toHTML(parentComponent), textMode);                                         // 142
  else                                                                                                  // 143
    throw new Error("Can't insert tags in attributes or TEXTAREA elements");                            // 144
};                                                                                                      // 145
                                                                                                        // 146
HTML.CharRef.prototype.toText = function (textMode) {                                                   // 147
  if (textMode === HTML.TEXTMODE.STRING)                                                                // 148
    return this.str;                                                                                    // 149
  else if (textMode === HTML.TEXTMODE.RCDATA)                                                           // 150
    return this.html;                                                                                   // 151
  else if (textMode === HTML.TEXTMODE.ATTRIBUTE)                                                        // 152
    return this.html;                                                                                   // 153
  else                                                                                                  // 154
    throw new Error("Unknown TEXTMODE: " + textMode);                                                   // 155
};                                                                                                      // 156
                                                                                                        // 157
//////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package.htmljs = {
  HTML: HTML
};

})();
