(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var Deps = Package.deps.Deps;
var Random = Package.random.Random;
var EJSON = Package.ejson.EJSON;
var _ = Package.underscore._;
var OrderedDict = Package['ordered-dict'].OrderedDict;
var LocalCollection = Package.minimongo.LocalCollection;
var Minimongo = Package.minimongo.Minimongo;
var ObserveSequence = Package['observe-sequence'].ObserveSequence;
var HTML = Package.htmljs.HTML;

/* Package-scope variables */
var UI, Handlebars, reportUIException, _extend, Component, findComponentWithProp, getComponentData, updateTemplateInstance, AttributeHandler, makeAttributeHandler;

(function () {

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                      //
// packages/ui/exceptions.js                                                                            //
//                                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                        //
                                                                                                        // 1
var debugFunc;                                                                                          // 2
                                                                                                        // 3
// Meteor UI calls into user code in many places, and it's nice to catch exceptions                     // 4
// propagated from user code immediately so that the whole system doesn't just                          // 5
// break.  Catching exceptions is easy; reporting them is hard.  This helper                            // 6
// reports exceptions.                                                                                  // 7
//                                                                                                      // 8
// Usage:                                                                                               // 9
//                                                                                                      // 10
// ```                                                                                                  // 11
// try {                                                                                                // 12
//   // ... someStuff ...                                                                               // 13
// } catch (e) {                                                                                        // 14
//   reportUIException(e);                                                                              // 15
// }                                                                                                    // 16
// ```                                                                                                  // 17
//                                                                                                      // 18
// An optional second argument overrides the default message.                                           // 19
                                                                                                        // 20
reportUIException = function (e, msg) {                                                                 // 21
  if (! debugFunc)                                                                                      // 22
    // adapted from Deps                                                                                // 23
    debugFunc = function () {                                                                           // 24
      return (typeof Meteor !== "undefined" ? Meteor._debug :                                           // 25
              ((typeof console !== "undefined") && console.log ? console.log :                          // 26
               function () {}));                                                                        // 27
    };                                                                                                  // 28
                                                                                                        // 29
  // In Chrome, `e.stack` is a multiline string that starts with the message                            // 30
  // and contains a stack trace.  Furthermore, `console.log` makes it clickable.                        // 31
  // `console.log` supplies the space between the two arguments.                                        // 32
  debugFunc()(msg || 'Exception in Meteor UI:', e.stack || e.message);                                  // 33
};                                                                                                      // 34
                                                                                                        // 35
//////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                      //
// packages/ui/base.js                                                                                  //
//                                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                        //
UI = {};                                                                                                // 1
                                                                                                        // 2
// A very basic operation like Underscore's `_.extend` that                                             // 3
// copies `src`'s own, enumerable properties onto `tgt` and                                             // 4
// returns `tgt`.                                                                                       // 5
_extend = function (tgt, src) {                                                                         // 6
  for (var k in src)                                                                                    // 7
    if (src.hasOwnProperty(k))                                                                          // 8
      tgt[k] = src[k];                                                                                  // 9
  return tgt;                                                                                           // 10
};                                                                                                      // 11
                                                                                                        // 12
// Defines a single non-enumerable, read-only property                                                  // 13
// on `tgt`.                                                                                            // 14
// It won't be non-enumerable in IE 8, so its                                                           // 15
// non-enumerability can't be relied on for logic                                                       // 16
// purposes, it just makes things prettier in                                                           // 17
// the dev console.                                                                                     // 18
var _defineNonEnum = function (tgt, name, value) {                                                      // 19
  try {                                                                                                 // 20
    Object.defineProperty(tgt, name, {value: value});                                                   // 21
  } catch (e) {                                                                                         // 22
    // IE < 9                                                                                           // 23
    tgt[name] = value;                                                                                  // 24
  }                                                                                                     // 25
  return tgt;                                                                                           // 26
};                                                                                                      // 27
                                                                                                        // 28
// Named function (like `function Component() {}` below) make                                           // 29
// inspection in debuggers more descriptive. In IE, this sets the                                       // 30
// value of the `Component` var in the function scope in which it's                                     // 31
// executed. We already have a top-level `Component` var so we create                                   // 32
// a new function scope to not write it over in IE.                                                     // 33
(function () {                                                                                          // 34
                                                                                                        // 35
  // Components and Component kinds are the same thing, just                                            // 36
  // objects; there are no constructor functions, no `new`,                                             // 37
  // and no `instanceof`.  A Component object is like a class,                                          // 38
  // until it is inited, at which point it becomes more like                                            // 39
  // an instance.                                                                                       // 40
  //                                                                                                    // 41
  // `y = x.extend({ ...new props })` creates a new Component                                           // 42
  // `y` with `x` as its prototype, plus additional properties                                          // 43
  // on `y` itself.  `extend` is used both to subclass and to                                           // 44
  // create instances (and the hope is we can gloss over the                                            // 45
  // difference in the docs).                                                                           // 46
  UI.Component = (function (constr) {                                                                   // 47
                                                                                                        // 48
    // Make sure the "class name" that Chrome infers for                                                // 49
    // UI.Component is "Component", and that                                                            // 50
    // `new UI.Component._constr` (which is what `extend`                                               // 51
    // does) also produces objects whose inferred class                                                 // 52
    // name is "Component".  Chrome's name inference rules                                              // 53
    // are a little mysterious, but a function name in                                                  // 54
    // the source code (as in `function Component() {}`)                                                // 55
    // seems to be reliable and high precedence.                                                        // 56
    var C = new constr;                                                                                 // 57
    _defineNonEnum(C, '_constr', constr);                                                               // 58
    _defineNonEnum(C, '_super', null);                                                                  // 59
    return C;                                                                                           // 60
  })(function Component() {});                                                                          // 61
})();                                                                                                   // 62
                                                                                                        // 63
_extend(UI, {                                                                                           // 64
  nextGuid: 2, // Component is 1!                                                                       // 65
                                                                                                        // 66
  isComponent: function (obj) {                                                                         // 67
    return obj && UI.isKindOf(obj, UI.Component);                                                       // 68
  },                                                                                                    // 69
  // `UI.isKindOf(a, b)` where `a` and `b` are Components                                               // 70
  // (or kinds) asks if `a` is or descends from                                                         // 71
  // (transitively extends) `b`.                                                                        // 72
  isKindOf: function (a, b) {                                                                           // 73
    while (a) {                                                                                         // 74
      if (a === b)                                                                                      // 75
        return true;                                                                                    // 76
      a = a._super;                                                                                     // 77
    }                                                                                                   // 78
    return false;                                                                                       // 79
  },                                                                                                    // 80
  // use these to produce error messages for developers                                                 // 81
  // (though throwing a more specific error message is                                                  // 82
  // even better)                                                                                       // 83
  _requireNotDestroyed: function (c) {                                                                  // 84
    if (c.isDestroyed)                                                                                  // 85
      throw new Error("Component has been destroyed; can't perform this operation");                    // 86
  },                                                                                                    // 87
  _requireInited: function (c) {                                                                        // 88
    if (! c.isInited)                                                                                   // 89
      throw new Error("Component must be inited to perform this operation");                            // 90
  },                                                                                                    // 91
  _requireDom: function (c) {                                                                           // 92
    if (! c.dom)                                                                                        // 93
      throw new Error("Component must be built into DOM to perform this operation");                    // 94
  }                                                                                                     // 95
});                                                                                                     // 96
                                                                                                        // 97
Component = UI.Component;                                                                               // 98
                                                                                                        // 99
_extend(UI.Component, {                                                                                 // 100
  kind: "Component",                                                                                    // 101
  guid: "1",                                                                                            // 102
  dom: null,                                                                                            // 103
  // Has this Component ever been inited?                                                               // 104
  isInited: false,                                                                                      // 105
  // Has this Component been destroyed?  Only inited Components                                         // 106
  // can be destroyed.                                                                                  // 107
  isDestroyed: false,                                                                                   // 108
  // Component that created this component (typically also                                              // 109
  // the DOM containment parent).                                                                       // 110
  // No child pointers (except in `dom`).                                                               // 111
  parent: null,                                                                                         // 112
                                                                                                        // 113
  // create a new subkind or instance whose proto pointer                                               // 114
  // points to this, with additional props set.                                                         // 115
  extend: function (props) {                                                                            // 116
    // this function should never cause `props` to be                                                   // 117
    // mutated in case people want to reuse `props` objects                                             // 118
    // in a mixin-like way.                                                                             // 119
                                                                                                        // 120
    if (this.isInited)                                                                                  // 121
      // Disallow extending inited Components so that                                                   // 122
      // inited Components don't inherit instance-specific                                              // 123
      // properties from other inited Components, just                                                  // 124
      // default values.                                                                                // 125
      throw new Error("Can't extend an inited Component");                                              // 126
                                                                                                        // 127
    var constr;                                                                                         // 128
    var constrMade = false;                                                                             // 129
    if (props && props.kind) {                                                                          // 130
      // If `kind` is different from super, set a constructor.                                          // 131
      // We used to set the function name here so that components                                       // 132
      // printed better in the console, but we took it out because                                      // 133
      // of CSP (and in hopes that Chrome finally adds proper                                           // 134
      // displayName support).                                                                          // 135
      constr = function () {};                                                                          // 136
      constrMade = true;                                                                                // 137
    } else {                                                                                            // 138
      constr = this._constr;                                                                            // 139
    }                                                                                                   // 140
                                                                                                        // 141
    // We don't know where we're getting `constr` from --                                               // 142
    // it might be from some supertype -- just that it has                                              // 143
    // the right function name.  So set the `prototype`                                                 // 144
    // property each time we use it as a constructor.                                                   // 145
    constr.prototype = this;                                                                            // 146
                                                                                                        // 147
    var c = new constr;                                                                                 // 148
    if (constrMade)                                                                                     // 149
      c._constr = constr;                                                                               // 150
                                                                                                        // 151
    if (props)                                                                                          // 152
      _extend(c, props);                                                                                // 153
                                                                                                        // 154
    // for efficient Component instantiations, we assign                                                // 155
    // as few things as possible here.                                                                  // 156
    _defineNonEnum(c, '_super', this);                                                                  // 157
    c.guid = String(UI.nextGuid++);                                                                     // 158
                                                                                                        // 159
    return c;                                                                                           // 160
  }                                                                                                     // 161
});                                                                                                     // 162
                                                                                                        // 163
//callChainedCallback = function (comp, propName, orig) {                                               // 164
  // Call `comp.foo`, `comp._super.foo`,                                                                // 165
  // `comp._super._super.foo`, and so on, but in reverse                                                // 166
  // order, and only if `foo` is an "own property" in each                                              // 167
  // case.  Furthermore, the passed value of `this` should                                              // 168
  // remain `comp` for all calls (which is achieved by                                                  // 169
  // filling in `orig` when recursing).                                                                 // 170
//  if (comp._super)                                                                                    // 171
//    callChainedCallback(comp._super, propName, orig || comp);                                         // 172
//                                                                                                      // 173
//  if (comp.hasOwnProperty(propName))                                                                  // 174
//    comp[propName].call(orig || comp);                                                                // 175
//};                                                                                                    // 176
                                                                                                        // 177
                                                                                                        // 178
// Returns 0 if the nodes are the same or either one contains the other;                                // 179
// otherwise, -1 if a comes before b, or else 1 if b comes before a in                                  // 180
// document order.                                                                                      // 181
// Requires: `a` and `b` are element nodes in the same document tree.                                   // 182
var compareElementIndex = function (a, b) {                                                             // 183
  // See http://ejohn.org/blog/comparing-document-position/                                             // 184
  if (a === b)                                                                                          // 185
    return 0;                                                                                           // 186
  if (a.compareDocumentPosition) {                                                                      // 187
    var n = a.compareDocumentPosition(b);                                                               // 188
    return ((n & 0x18) ? 0 : ((n & 0x4) ? -1 : 1));                                                     // 189
  } else {                                                                                              // 190
    // Only old IE is known to not have compareDocumentPosition (though Safari                          // 191
    // originally lacked it).  Thankfully, IE gives us a way of comparing elements                      // 192
    // via the "sourceIndex" property.                                                                  // 193
    if (a.contains(b) || b.contains(a))                                                                 // 194
      return 0;                                                                                         // 195
    return (a.sourceIndex < b.sourceIndex ? -1 : 1);                                                    // 196
  }                                                                                                     // 197
};                                                                                                      // 198
                                                                                                        // 199
findComponentWithProp = function (id, comp) {                                                           // 200
  while (comp) {                                                                                        // 201
    if (typeof comp[id] !== 'undefined')                                                                // 202
      return comp;                                                                                      // 203
    comp = comp.parent;                                                                                 // 204
  }                                                                                                     // 205
  return null;                                                                                          // 206
};                                                                                                      // 207
                                                                                                        // 208
getComponentData = function (comp) {                                                                    // 209
  comp = findComponentWithProp('data', comp);                                                           // 210
  return (comp ?                                                                                        // 211
          (typeof comp.data === 'function' ?                                                            // 212
           comp.data() : comp.data) :                                                                   // 213
          null);                                                                                        // 214
};                                                                                                      // 215
                                                                                                        // 216
updateTemplateInstance = function (comp) {                                                              // 217
  // Populate `comp.templateInstance.{firstNode,lastNode,data}`                                         // 218
  // on demand.                                                                                         // 219
  var tmpl = comp.templateInstance;                                                                     // 220
  tmpl.data = getComponentData(comp);                                                                   // 221
                                                                                                        // 222
  if (comp.dom && !comp.isDestroyed) {                                                                  // 223
    tmpl.firstNode = comp.dom.startNode().nextSibling;                                                  // 224
    tmpl.lastNode = comp.dom.endNode().previousSibling;                                                 // 225
    // Catch the case where the DomRange is empty and we'd                                              // 226
    // otherwise pass the out-of-order nodes (end, start)                                               // 227
    // as (firstNode, lastNode).                                                                        // 228
    if (tmpl.lastNode && tmpl.lastNode.nextSibling === tmpl.firstNode)                                  // 229
      tmpl.lastNode = tmpl.firstNode;                                                                   // 230
  } else {                                                                                              // 231
    // on 'created' or 'destroyed' callbacks we don't have a DomRange                                   // 232
    tmpl.firstNode = null;                                                                              // 233
    tmpl.lastNode = null;                                                                               // 234
  }                                                                                                     // 235
};                                                                                                      // 236
                                                                                                        // 237
_extend(UI.Component, {                                                                                 // 238
  // We implement the old APIs here, including how data is passed                                       // 239
  // to helpers in `this`.                                                                              // 240
  helpers: function (dict) {                                                                            // 241
    _extend(this, dict);                                                                                // 242
  },                                                                                                    // 243
  events: function (dict) {                                                                             // 244
    var events;                                                                                         // 245
    if (this.hasOwnProperty('_events'))                                                                 // 246
      events = this._events;                                                                            // 247
    else                                                                                                // 248
      events = (this._events = []);                                                                     // 249
                                                                                                        // 250
    _.each(dict, function (handler, spec) {                                                             // 251
      var clauses = spec.split(/,\s+/);                                                                 // 252
      // iterate over clauses of spec, e.g. ['click .foo', 'click .bar']                                // 253
      _.each(clauses, function (clause) {                                                               // 254
        var parts = clause.split(/\s+/);                                                                // 255
        if (parts.length === 0)                                                                         // 256
          return;                                                                                       // 257
                                                                                                        // 258
        var newEvents = parts.shift();                                                                  // 259
        var selector = parts.join(' ');                                                                 // 260
        events.push({events: newEvents,                                                                 // 261
                     selector: selector,                                                                // 262
                     handler: handler});                                                                // 263
      });                                                                                               // 264
    });                                                                                                 // 265
  }                                                                                                     // 266
});                                                                                                     // 267
                                                                                                        // 268
// XXX we don't really want this to be a user-visible callback,                                         // 269
// it's just a particular signal we need from DomRange.                                                 // 270
UI.Component.notifyParented = function () {                                                             // 271
  var self = this;                                                                                      // 272
  for (var comp = self; comp; comp = comp._super) {                                                     // 273
    var events = (comp.hasOwnProperty('_events') && comp._events) || null;                              // 274
    if ((! events) && comp.hasOwnProperty('events') &&                                                  // 275
        typeof comp.events === 'object') {                                                              // 276
      // Provide limited back-compat support for `.events = {...}`                                      // 277
      // syntax.  Pass `comp.events` to the original `.events(...)`                                     // 278
      // function.  This code must run only once per component, in                                      // 279
      // order to not bind the handlers more than once, which is                                        // 280
      // ensured by the fact that we only do this when `comp._events`                                   // 281
      // is falsy, and we cause it to be set now.                                                       // 282
      UI.Component.events.call(comp, comp.events);                                                      // 283
      events = comp._events;                                                                            // 284
    }                                                                                                   // 285
    _.each(events, function (esh) { // {events, selector, handler}                                      // 286
      // wrap the handler here, per instance of the template that                                       // 287
      // declares the event map, so we can pass the instance to                                         // 288
      // the event handler.                                                                             // 289
      var wrappedHandler = function (event) {                                                           // 290
        var comp = UI.DomRange.getContainingComponent(event.currentTarget);                             // 291
        var data = comp && getComponentData(comp);                                                      // 292
        updateTemplateInstance(self);                                                                   // 293
        Deps.nonreactive(function () {                                                                  // 294
          // Don't want to be in a deps context, even if we were somehow                                // 295
          // triggered synchronously in an existing deps context                                        // 296
          // (the `blur` event can do this).                                                            // 297
          // XXX we should probably do what Spark did and block all                                     // 298
          // event handling during our DOM manip.  Many apps had weird                                  // 299
          // unanticipated bugs until we did that.                                                      // 300
          esh.handler.call(data, event, self.templateInstance);                                         // 301
        });                                                                                             // 302
      };                                                                                                // 303
                                                                                                        // 304
      self.dom.on(esh.events, esh.selector, wrappedHandler);                                            // 305
    });                                                                                                 // 306
  }                                                                                                     // 307
                                                                                                        // 308
  // XXX this is an undocumented callback                                                               // 309
  if (self.parented) {                                                                                  // 310
    Deps.nonreactive(function () {                                                                      // 311
      updateTemplateInstance(self);                                                                     // 312
      self.parented.call(self.templateInstance);                                                        // 313
    });                                                                                                 // 314
  }                                                                                                     // 315
                                                                                                        // 316
  if (self.rendered) {                                                                                  // 317
    // Defer rendered callback until flush time.                                                        // 318
    Deps.afterFlush(function () {                                                                       // 319
      if (! self.isDestroyed) {                                                                         // 320
        updateTemplateInstance(self);                                                                   // 321
        self.rendered.call(self.templateInstance);                                                      // 322
      }                                                                                                 // 323
    });                                                                                                 // 324
  }                                                                                                     // 325
};                                                                                                      // 326
                                                                                                        // 327
// past compat                                                                                          // 328
UI.Component.preserve = function () {                                                                   // 329
  Meteor._debug("The 'preserve' method on templates is now unnecessary and deprecated.");               // 330
};                                                                                                      // 331
                                                                                                        // 332
// Gets the data context of the enclosing component that rendered a                                     // 333
// given element                                                                                        // 334
UI.getElementData = function (el) {                                                                     // 335
  var comp = UI.DomRange.getContainingComponent(el);                                                    // 336
  return comp && getComponentData(comp);                                                                // 337
};                                                                                                      // 338
                                                                                                        // 339
                                                                                                        // 340
//////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                      //
// packages/ui/attrs.js                                                                                 //
//                                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                        //
                                                                                                        // 1
// An AttributeHandler object is responsible for updating a particular attribute                        // 2
// of a particular element.  AttributeHandler subclasses implement                                      // 3
// browser-specific logic for dealing with particular attributes across                                 // 4
// different browsers.                                                                                  // 5
//                                                                                                      // 6
// To define a new type of AttributeHandler, use                                                        // 7
// `var FooHandler = AttributeHandler.extend({ update: function ... })`                                 // 8
// where the `update` function takes arguments `(element, oldValue, value)`.                            // 9
// The `element` argument is always the same between calls to `update` on                               // 10
// the same instance.  `oldValue` and `value` are each either `null` or                                 // 11
// a Unicode string of the type that might be passed to the value argument                              // 12
// of `setAttribute` (i.e. not an HTML string with character references).                               // 13
// When an AttributeHandler is installed, an initial call to `update` is                                // 14
// always made with `oldValue = null`.  The `update` method can access                                  // 15
// `this.name` if the AttributeHandler class is a generic one that applies                              // 16
// to multiple attribute names.                                                                         // 17
//                                                                                                      // 18
// AttributeHandlers can store custom properties on `this`, as long as they                             // 19
// don't use the names `element`, `name`, `value`, and `oldValue`.                                      // 20
//                                                                                                      // 21
// AttributeHandlers can't influence how attributes appear in rendered HTML,                            // 22
// only how they are updated after materialization as DOM.                                              // 23
                                                                                                        // 24
AttributeHandler = function (name, value) {                                                             // 25
  this.name = name;                                                                                     // 26
  this.value = value;                                                                                   // 27
};                                                                                                      // 28
                                                                                                        // 29
_.extend(AttributeHandler.prototype, {                                                                  // 30
  update: function (element, oldValue, value) {                                                         // 31
    if (value === null) {                                                                               // 32
      if (oldValue !== null)                                                                            // 33
        element.removeAttribute(this.name);                                                             // 34
    } else {                                                                                            // 35
      element.setAttribute(this.name, this.value);                                                      // 36
    }                                                                                                   // 37
  }                                                                                                     // 38
});                                                                                                     // 39
                                                                                                        // 40
AttributeHandler.extend = function (options) {                                                          // 41
  var curType = this;                                                                                   // 42
  var subType = function AttributeHandlerSubtype(/*arguments*/) {                                       // 43
    AttributeHandler.apply(this, arguments);                                                            // 44
  };                                                                                                    // 45
  subType.prototype = new curType;                                                                      // 46
  subType.extend = curType.extend;                                                                      // 47
  if (options)                                                                                          // 48
    _.extend(subType.prototype, options);                                                               // 49
  return subType;                                                                                       // 50
};                                                                                                      // 51
                                                                                                        // 52
// Extended below to support both regular and SVG elements                                              // 53
var BaseClassHandler = AttributeHandler.extend({                                                        // 54
  update: function (element, oldValue, value) {                                                         // 55
    if (!this.getCurrentValue || !this.setValue)                                                        // 56
      throw new Error("Missing methods in subclass of 'BaseClassHandler'");                             // 57
                                                                                                        // 58
    var oldClasses = oldValue ? _.compact(oldValue.split(' ')) : [];                                    // 59
    var newClasses = value ? _.compact(value.split(' ')) : [];                                          // 60
                                                                                                        // 61
    // the current classes on the element, which we will mutate.                                        // 62
    var classes = _.compact(this.getCurrentValue(element).split(' '));                                  // 63
                                                                                                        // 64
    // optimize this later (to be asymptotically faster) if necessary                                   // 65
    _.each(oldClasses, function (c) {                                                                   // 66
      if (_.indexOf(newClasses, c) < 0)                                                                 // 67
        classes = _.without(classes, c);                                                                // 68
    });                                                                                                 // 69
    _.each(newClasses, function (c) {                                                                   // 70
      if (_.indexOf(oldClasses, c) < 0 &&                                                               // 71
          _.indexOf(classes, c) < 0)                                                                    // 72
        classes.push(c);                                                                                // 73
    });                                                                                                 // 74
                                                                                                        // 75
    this.setValue(element, classes.join(' '));                                                          // 76
  }                                                                                                     // 77
});                                                                                                     // 78
                                                                                                        // 79
var ClassHandler = BaseClassHandler.extend({                                                            // 80
  // @param rawValue {String}                                                                           // 81
  getCurrentValue: function (element) {                                                                 // 82
    return element.className;                                                                           // 83
  },                                                                                                    // 84
  setValue: function (element, className) {                                                             // 85
    element.className = className;                                                                      // 86
  }                                                                                                     // 87
});                                                                                                     // 88
                                                                                                        // 89
var SVGClassHandler = BaseClassHandler.extend({                                                         // 90
  getCurrentValue: function (element) {                                                                 // 91
    return element.className.baseVal;                                                                   // 92
  },                                                                                                    // 93
  setValue: function (element, className) {                                                             // 94
    element.setAttribute('class', className);                                                           // 95
  }                                                                                                     // 96
});                                                                                                     // 97
                                                                                                        // 98
var BooleanHandler = AttributeHandler.extend({                                                          // 99
  update: function (element, oldValue, value) {                                                         // 100
    var focused = this.focused(element);                                                                // 101
                                                                                                        // 102
    if (!focused) {                                                                                     // 103
      var name = this.name;                                                                             // 104
      if (value == null) {                                                                              // 105
        if (oldValue != null)                                                                           // 106
          element[name] = false;                                                                        // 107
      } else {                                                                                          // 108
        element[name] = true;                                                                           // 109
      }                                                                                                 // 110
    }                                                                                                   // 111
  },                                                                                                    // 112
  // is the element part of a control which is focused?                                                 // 113
  focused: function (element) {                                                                         // 114
    if (element.tagName === 'INPUT') {                                                                  // 115
      return element === document.activeElement;                                                        // 116
                                                                                                        // 117
    } else if (element.tagName === 'OPTION') {                                                          // 118
      // find the containing SELECT element, on which focus                                             // 119
      // is actually set                                                                                // 120
      var selectEl = element;                                                                           // 121
      while (selectEl && selectEl.tagName !== 'SELECT')                                                 // 122
        selectEl = selectEl.parentNode;                                                                 // 123
                                                                                                        // 124
      if (selectEl)                                                                                     // 125
        return selectEl === document.activeElement;                                                     // 126
      else                                                                                              // 127
        return false;                                                                                   // 128
    } else {                                                                                            // 129
      throw new Error("Expected INPUT or OPTION element");                                              // 130
    }                                                                                                   // 131
  }                                                                                                     // 132
});                                                                                                     // 133
                                                                                                        // 134
var ValueHandler = AttributeHandler.extend({                                                            // 135
  update: function (element, oldValue, value) {                                                         // 136
    var focused = (element === document.activeElement);                                                 // 137
                                                                                                        // 138
    if (!focused)                                                                                       // 139
      element.value = value;                                                                            // 140
  }                                                                                                     // 141
});                                                                                                     // 142
                                                                                                        // 143
// attributes of the type 'xlink:something' should be set using                                         // 144
// the correct namespace in order to work                                                               // 145
var XlinkHandler = AttributeHandler.extend({                                                            // 146
  update: function(element, oldValue, value) {                                                          // 147
    var NS = 'http://www.w3.org/1999/xlink';                                                            // 148
    if (value === null) {                                                                               // 149
      if (oldValue !== null)                                                                            // 150
        element.removeAttributeNS(NS, this.name);                                                       // 151
    } else {                                                                                            // 152
      element.setAttributeNS(NS, this.name, this.value);                                                // 153
    }                                                                                                   // 154
  }                                                                                                     // 155
});                                                                                                     // 156
                                                                                                        // 157
// cross-browser version of `instanceof SVGElement`                                                     // 158
var isSVGElement = function (elem) {                                                                    // 159
  return 'ownerSVGElement' in elem;                                                                     // 160
};                                                                                                      // 161
                                                                                                        // 162
// XXX make it possible for users to register attribute handlers!                                       // 163
makeAttributeHandler = function (elem, name, value) {                                                   // 164
  // generally, use setAttribute but certain attributes need to be set                                  // 165
  // by directly setting a JavaScript property on the DOM element.                                      // 166
  if (name === 'class') {                                                                               // 167
    if (isSVGElement(elem)) {                                                                           // 168
      return new SVGClassHandler(name, value);                                                          // 169
    } else {                                                                                            // 170
      return new ClassHandler(name, value);                                                             // 171
    }                                                                                                   // 172
  } else if ((elem.tagName === 'OPTION' && name === 'selected') ||                                      // 173
             (elem.tagName === 'INPUT' && name === 'checked')) {                                        // 174
    return new BooleanHandler(name, value);                                                             // 175
  } else if ((elem.tagName === 'TEXTAREA' || elem.tagName === 'INPUT')                                  // 176
             && name === 'value') {                                                                     // 177
    // internally, TEXTAREAs tracks their value in the 'value'                                          // 178
    // attribute just like INPUTs.                                                                      // 179
    return new ValueHandler(name, value);                                                               // 180
  } else if (name.substring(0,6) === 'xlink:') {                                                        // 181
    return new XlinkHandler(name.substring(6), value);                                                  // 182
  } else {                                                                                              // 183
    return new AttributeHandler(name, value);                                                           // 184
  }                                                                                                     // 185
                                                                                                        // 186
  // XXX will need one for 'style' on IE, though modern browsers                                        // 187
  // seem to handle setAttribute ok.                                                                    // 188
};                                                                                                      // 189
                                                                                                        // 190
//////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                      //
// packages/ui/render.js                                                                                //
//                                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                        //
                                                                                                        // 1
UI.Component.instantiate = function (parent) {                                                          // 2
  var kind = this;                                                                                      // 3
                                                                                                        // 4
  // check arguments                                                                                    // 5
  if (UI.isComponent(kind)) {                                                                           // 6
    if (kind.isInited)                                                                                  // 7
      throw new Error("A component kind is required, not an instance");                                 // 8
  } else {                                                                                              // 9
    throw new Error("Expected Component kind");                                                         // 10
  }                                                                                                     // 11
                                                                                                        // 12
  var inst = kind.extend(); // XXX args go here                                                         // 13
  inst.isInited = true;                                                                                 // 14
                                                                                                        // 15
  // XXX messy to define this here                                                                      // 16
  inst.templateInstance = {                                                                             // 17
    findAll: function (selector) {                                                                      // 18
      // XXX check that `.dom` exists here?                                                             // 19
      return inst.dom.$(selector);                                                                      // 20
    },                                                                                                  // 21
    find: function (selector) {                                                                         // 22
      var result = this.findAll(selector);                                                              // 23
      return result[0] || null;                                                                         // 24
    },                                                                                                  // 25
    firstNode: null,                                                                                    // 26
    lastNode: null,                                                                                     // 27
    data: null,                                                                                         // 28
    __component__: inst                                                                                 // 29
  };                                                                                                    // 30
                                                                                                        // 31
  inst.parent = (parent || null);                                                                       // 32
                                                                                                        // 33
  if (inst.init)                                                                                        // 34
    inst.init();                                                                                        // 35
                                                                                                        // 36
  if (inst.created) {                                                                                   // 37
    updateTemplateInstance(inst);                                                                       // 38
    inst.created.call(inst.templateInstance);                                                           // 39
  }                                                                                                     // 40
                                                                                                        // 41
  return inst;                                                                                          // 42
};                                                                                                      // 43
                                                                                                        // 44
UI.Component.render = function () {                                                                     // 45
  return null;                                                                                          // 46
};                                                                                                      // 47
                                                                                                        // 48
                                                                                                        // 49
// Takes a reactive function (call it `inner`) and returns a reactive function                          // 50
// `outer` which is equivalent except in its reactive behavior.  Specifically,                          // 51
// `outer` has the following two special properties:                                                    // 52
//                                                                                                      // 53
// 1. Isolation:  An invocation of `outer()` only invalidates its context                               // 54
//    when the value of `inner()` changes.  For example, `inner` may be a                               // 55
//    function that gets one or more Session variables and calculates a                                 // 56
//    true/false value.  `outer` blocks invalidation signals caused by the                              // 57
//    Session variables changing and sends a signal out only when the value                             // 58
//    changes between true and false (in this example).  The value can be                               // 59
//    of any type, and it is compared with `===` unless an `equals` function                            // 60
//    is provided.                                                                                      // 61
//                                                                                                      // 62
// 2. Value Sharing:  The `outer` function returned by `emboxValue` can be                              // 63
//    shared between different contexts, for example by assigning it to an                              // 64
//    object as a method that can be accessed at any time, such as by                                   // 65
//    different templates or different parts of a template.  No matter                                  // 66
//    how many times `outer` is called, `inner` is only called once until                               // 67
//    it changes.  The most recent value is stored internally.                                          // 68
//                                                                                                      // 69
// Conceptually, an emboxed value is much like a Session variable which is                              // 70
// kept up to date by an autorun.  Session variables provide storage                                    // 71
// (value sharing) and they don't notify their listeners unless a value                                 // 72
// actually changes (isolation).  The biggest difference is that such an                                // 73
// autorun would never be stopped, and the Session variable would never be                              // 74
// deleted even if it wasn't used any more.  An emboxed value, on the other                             // 75
// hand, automatically stops computing when it's not being used, and starts                             // 76
// again when called from a reactive context.  This means that when it stops                            // 77
// being used, it can be completely garbage-collected.                                                  // 78
//                                                                                                      // 79
// If a non-function value is supplied to `emboxValue` instead of a reactive                            // 80
// function, then `outer` is still a function but it simply returns the value.                          // 81
//                                                                                                      // 82
UI.emboxValue = function (funcOrValue, equals) {                                                        // 83
  if (typeof funcOrValue === 'function') {                                                              // 84
    var func = funcOrValue;                                                                             // 85
                                                                                                        // 86
    var curResult = null;                                                                               // 87
    // There's one shared Dependency and Computation for all callers of                                 // 88
    // our box function.  It gets kicked off if necessary, and when                                     // 89
    // there are no more dependents, it gets stopped to avoid leaking                                   // 90
    // memory.                                                                                          // 91
    var resultDep = null;                                                                               // 92
    var computation = null;                                                                             // 93
                                                                                                        // 94
    return function () {                                                                                // 95
      if (! computation) {                                                                              // 96
        if (! Deps.active) {                                                                            // 97
          // Not in a reactive context.  Just call func, and don't start a                              // 98
          // computation if there isn't one running already.                                            // 99
          return func();                                                                                // 100
        }                                                                                               // 101
                                                                                                        // 102
        // No running computation, so kick one off.  Since this computation                             // 103
        // will be shared, avoid any association with the current computation                           // 104
        // by using `Deps.nonreactive`.                                                                 // 105
        resultDep = new Deps.Dependency;                                                                // 106
                                                                                                        // 107
        computation = Deps.nonreactive(function () {                                                    // 108
          return Deps.autorun(function (c) {                                                            // 109
            var oldResult = curResult;                                                                  // 110
            curResult = func();                                                                         // 111
            if (! c.firstRun) {                                                                         // 112
              if (! (equals ? equals(curResult, oldResult) :                                            // 113
                     curResult === oldResult))                                                          // 114
                resultDep.changed();                                                                    // 115
            }                                                                                           // 116
          });                                                                                           // 117
        });                                                                                             // 118
      }                                                                                                 // 119
                                                                                                        // 120
      if (Deps.active) {                                                                                // 121
        var isNew = resultDep.depend();                                                                 // 122
        if (isNew) {                                                                                    // 123
          // For each new dependent, schedule a task for after that dependent's                         // 124
          // invalidation time and the subsequent flush. The task checks                                // 125
          // whether the computation should be torn down.                                               // 126
          Deps.onInvalidate(function () {                                                               // 127
            if (resultDep && ! resultDep.hasDependents()) {                                             // 128
              Deps.afterFlush(function () {                                                             // 129
                // use a second afterFlush to bump ourselves to the END of the                          // 130
                // flush, after computation re-runs have had a chance to                                // 131
                // re-establish their connections to our computation.                                   // 132
                Deps.afterFlush(function () {                                                           // 133
                  if (resultDep && ! resultDep.hasDependents()) {                                       // 134
                    computation.stop();                                                                 // 135
                    computation = null;                                                                 // 136
                    resultDep = null;                                                                   // 137
                  }                                                                                     // 138
                });                                                                                     // 139
              });                                                                                       // 140
            }                                                                                           // 141
          });                                                                                           // 142
        }                                                                                               // 143
      }                                                                                                 // 144
                                                                                                        // 145
      return curResult;                                                                                 // 146
    };                                                                                                  // 147
                                                                                                        // 148
  } else {                                                                                              // 149
    var value = funcOrValue;                                                                            // 150
    var result = function () {                                                                          // 151
      return value;                                                                                     // 152
    };                                                                                                  // 153
    result._isEmboxedConstant = true;                                                                   // 154
    return result;                                                                                      // 155
  }                                                                                                     // 156
};                                                                                                      // 157
                                                                                                        // 158
                                                                                                        // 159
////////////////////////////////////////                                                                // 160
                                                                                                        // 161
UI.insert = function (renderedTemplate, parentElement, nextNode) {                                      // 162
  if (! renderedTemplate.dom)                                                                           // 163
    throw new Error("Expected template rendered with UI.render");                                       // 164
                                                                                                        // 165
  UI.DomRange.insert(renderedTemplate.dom, parentElement, nextNode);                                    // 166
};                                                                                                      // 167
                                                                                                        // 168
// Insert a DOM node or DomRange into a DOM element or DomRange.                                        // 169
//                                                                                                      // 170
// One of three things happens depending on what needs to be inserted into what:                        // 171
// - `range.add` (anything into DomRange)                                                               // 172
// - `UI.DomRange.insert` (DomRange into element)                                                       // 173
// - `elem.insertBefore` (node into element)                                                            // 174
//                                                                                                      // 175
// The optional `before` argument is an existing node or id to insert before in                         // 176
// the parent element or DomRange.                                                                      // 177
var insert = function (nodeOrRange, parent, before) {                                                   // 178
  if (! parent)                                                                                         // 179
    throw new Error("Materialization parent required");                                                 // 180
                                                                                                        // 181
  if (parent instanceof UI.DomRange) {                                                                  // 182
    parent.add(nodeOrRange, before);                                                                    // 183
  } else if (nodeOrRange instanceof UI.DomRange) {                                                      // 184
    // parent is an element; inserting a range                                                          // 185
    UI.DomRange.insert(nodeOrRange, parent, before);                                                    // 186
  } else {                                                                                              // 187
    // parent is an element; inserting an element                                                       // 188
    parent.insertBefore(nodeOrRange, before || null); // `null` for IE                                  // 189
  }                                                                                                     // 190
};                                                                                                      // 191
                                                                                                        // 192
// Update attributes on `elem` to the dictionary `attrs`, using the                                     // 193
// dictionary of existing `handlers` if provided.                                                       // 194
//                                                                                                      // 195
// Values in the `attrs` dictionary are in pseudo-DOM form -- a string,                                 // 196
// CharRef, or array of strings and CharRefs -- but they are passed to                                  // 197
// the AttributeHandler in string form.                                                                 // 198
var updateAttributes = function(elem, newAttrs, handlers) {                                             // 199
                                                                                                        // 200
  if (handlers) {                                                                                       // 201
    for (var k in handlers) {                                                                           // 202
      if (! newAttrs.hasOwnProperty(k)) {                                                               // 203
        // remove attributes (and handlers) for attribute names                                         // 204
        // that don't exist as keys of `newAttrs` and so won't                                          // 205
        // be visited when traversing it.  (Attributes that                                             // 206
        // exist in the `newAttrs` object but are `null`                                                // 207
        // are handled later.)                                                                          // 208
        var handler = handlers[k];                                                                      // 209
        var oldValue = handler.value;                                                                   // 210
        handler.value = null;                                                                           // 211
        handler.update(elem, oldValue, null);                                                           // 212
        delete handlers[k];                                                                             // 213
      }                                                                                                 // 214
    }                                                                                                   // 215
  }                                                                                                     // 216
                                                                                                        // 217
  for (var k in newAttrs) {                                                                             // 218
    var handler = null;                                                                                 // 219
    var oldValue;                                                                                       // 220
    var value = newAttrs[k];                                                                            // 221
    if ((! handlers) || (! handlers.hasOwnProperty(k))) {                                               // 222
      if (value !== null) {                                                                             // 223
        // make new handler                                                                             // 224
        handler = makeAttributeHandler(elem, k, value);                                                 // 225
        if (handlers)                                                                                   // 226
          handlers[k] = handler;                                                                        // 227
        oldValue = null;                                                                                // 228
      }                                                                                                 // 229
    } else {                                                                                            // 230
      handler = handlers[k];                                                                            // 231
      oldValue = handler.value;                                                                         // 232
    }                                                                                                   // 233
    if (handler && oldValue !== value) {                                                                // 234
      handler.value = value;                                                                            // 235
      handler.update(elem, oldValue, value);                                                            // 236
      if (value === null)                                                                               // 237
        delete handlers[k];                                                                             // 238
    }                                                                                                   // 239
  }                                                                                                     // 240
};                                                                                                      // 241
                                                                                                        // 242
UI.render = function (kind, parentComponent) {                                                          // 243
  if (kind.isInited)                                                                                    // 244
    throw new Error("Can't render component instance, only component kind");                            // 245
                                                                                                        // 246
  var inst, content, range;                                                                             // 247
                                                                                                        // 248
  Deps.nonreactive(function () {                                                                        // 249
                                                                                                        // 250
    inst = kind.instantiate(parentComponent);                                                           // 251
                                                                                                        // 252
    content = (inst.render && inst.render());                                                           // 253
                                                                                                        // 254
    range = new UI.DomRange;                                                                            // 255
    inst.dom = range;                                                                                   // 256
    range.component = inst;                                                                             // 257
                                                                                                        // 258
  });                                                                                                   // 259
                                                                                                        // 260
  materialize(content, range, null, inst);                                                              // 261
                                                                                                        // 262
  range.removed = function () {                                                                         // 263
    inst.isDestroyed = true;                                                                            // 264
    if (inst.destroyed) {                                                                               // 265
      Deps.nonreactive(function () {                                                                    // 266
        updateTemplateInstance(inst);                                                                   // 267
        inst.destroyed.call(inst.templateInstance);                                                     // 268
      });                                                                                               // 269
    }                                                                                                   // 270
  };                                                                                                    // 271
                                                                                                        // 272
  return inst;                                                                                          // 273
};                                                                                                      // 274
                                                                                                        // 275
UI.renderWithData = function (kind, data, parentComponent) {                                            // 276
  if (! UI.isComponent(kind))                                                                           // 277
    throw new Error("Component required here");                                                         // 278
  if (kind.isInited)                                                                                    // 279
    throw new Error("Can't render component instance, only component kind");                            // 280
  if (typeof data === 'function')                                                                       // 281
    throw new Error("Data argument can't be a function");                                               // 282
                                                                                                        // 283
  return UI.render(kind.extend({data: function () { return data; }}),                                   // 284
                   parentComponent);                                                                    // 285
};                                                                                                      // 286
                                                                                                        // 287
var contentEquals = function (a, b) {                                                                   // 288
  if (a instanceof HTML.Raw) {                                                                          // 289
    return (b instanceof HTML.Raw) && (a.value === b.value);                                            // 290
  } else if (a == null) {                                                                               // 291
    return (b == null);                                                                                 // 292
  } else {                                                                                              // 293
    return (a === b) &&                                                                                 // 294
      ((typeof a === 'number') || (typeof a === 'boolean') ||                                           // 295
       (typeof a === 'string'));                                                                        // 296
  }                                                                                                     // 297
};                                                                                                      // 298
                                                                                                        // 299
UI.InTemplateScope = function (tmplInstance, content) {                                                 // 300
  if (! (this instanceof UI.InTemplateScope))                                                           // 301
    // called without `new`                                                                             // 302
    return new UI.InTemplateScope(tmplInstance, content);                                               // 303
                                                                                                        // 304
  var parentPtr = tmplInstance.parent;                                                                  // 305
  if (parentPtr.__isTemplateWith)                                                                       // 306
    parentPtr = parentPtr.parent;                                                                       // 307
                                                                                                        // 308
  this.parentPtr = parentPtr;                                                                           // 309
  this.content = content;                                                                               // 310
};                                                                                                      // 311
                                                                                                        // 312
UI.InTemplateScope.prototype.toHTML = function (parentComponent) {                                      // 313
  return HTML.toHTML(this.content, this.parentPtr);                                                     // 314
};                                                                                                      // 315
                                                                                                        // 316
UI.InTemplateScope.prototype.toText = function (textMode, parentComponent) {                            // 317
  return HTML.toText(this.content, textMode, this.parentPtr);                                           // 318
};                                                                                                      // 319
                                                                                                        // 320
// Convert the pseudoDOM `node` into reactive DOM nodes and insert them                                 // 321
// into the element or DomRange `parent`, before the node or id `before`.                               // 322
var materialize = function (node, parent, before, parentComponent) {                                    // 323
  // XXX should do more error-checking for the case where user is supplying the tags.                   // 324
  // For example, check that CharRef has `html` and `str` properties and no content.                    // 325
  // Check that Comment has a single string child and no attributes.  Etc.                              // 326
                                                                                                        // 327
  if (node == null) {                                                                                   // 328
    // null or undefined.                                                                               // 329
    // do nothinge.                                                                                     // 330
  } else if ((typeof node === 'string') || (typeof node === 'boolean') || (typeof node === 'number')) { // 331
    node = String(node);                                                                                // 332
    insert(document.createTextNode(node), parent, before);                                              // 333
  } else if (node instanceof Array) {                                                                   // 334
    for (var i = 0; i < node.length; i++)                                                               // 335
      materialize(node[i], parent, before, parentComponent);                                            // 336
  } else if (typeof node === 'function') {                                                              // 337
                                                                                                        // 338
    var range = new UI.DomRange;                                                                        // 339
    var lastContent = null;                                                                             // 340
    var rangeUpdater = Deps.autorun(function (c) {                                                      // 341
      var content = node();                                                                             // 342
      // normalize content a little, for easier comparison                                              // 343
      if (HTML.isNully(content))                                                                        // 344
        content = null;                                                                                 // 345
      else if ((content instanceof Array) && content.length === 1)                                      // 346
        content = content[0];                                                                           // 347
                                                                                                        // 348
      // update if content is different from last time                                                  // 349
      if (! contentEquals(content, lastContent)) {                                                      // 350
        lastContent = content;                                                                          // 351
                                                                                                        // 352
        if (! c.firstRun)                                                                               // 353
          range.removeAll();                                                                            // 354
                                                                                                        // 355
        materialize(content, range, null, parentComponent);                                             // 356
      }                                                                                                 // 357
    });                                                                                                 // 358
    range.removed = function () {                                                                       // 359
      rangeUpdater.stop();                                                                              // 360
    };                                                                                                  // 361
    insert(range, parent, before);                                                                      // 362
  } else if (node instanceof HTML.Tag) {                                                                // 363
    var tagName = node.tagName;                                                                         // 364
    var elem;                                                                                           // 365
    if (HTML.isKnownSVGElement(tagName) && document.createElementNS) {                                  // 366
      elem = document.createElementNS('http://www.w3.org/2000/svg', tagName);                           // 367
    } else {                                                                                            // 368
      elem = document.createElement(node.tagName);                                                      // 369
    }                                                                                                   // 370
                                                                                                        // 371
    var rawAttrs = node.attrs;                                                                          // 372
    var children = node.children;                                                                       // 373
    if (node.tagName === 'textarea') {                                                                  // 374
      rawAttrs = (rawAttrs || {});                                                                      // 375
      rawAttrs.value = children;                                                                        // 376
      children = [];                                                                                    // 377
    };                                                                                                  // 378
                                                                                                        // 379
    if (rawAttrs) {                                                                                     // 380
      var attrUpdater = Deps.autorun(function (c) {                                                     // 381
        if (! c.handlers)                                                                               // 382
          c.handlers = {};                                                                              // 383
                                                                                                        // 384
        try {                                                                                           // 385
          var attrs = HTML.evaluateAttributes(rawAttrs, parentComponent);                               // 386
          var stringAttrs = {};                                                                         // 387
          if (attrs) {                                                                                  // 388
            for (var k in attrs) {                                                                      // 389
              stringAttrs[k] = HTML.toText(attrs[k], HTML.TEXTMODE.STRING,                              // 390
                                           parentComponent);                                            // 391
            }                                                                                           // 392
            updateAttributes(elem, stringAttrs, c.handlers);                                            // 393
          }                                                                                             // 394
        } catch (e) {                                                                                   // 395
          reportUIException(e);                                                                         // 396
        }                                                                                               // 397
      });                                                                                               // 398
      UI.DomBackend.onRemoveElement(elem, function () {                                                 // 399
        attrUpdater.stop();                                                                             // 400
      });                                                                                               // 401
    }                                                                                                   // 402
    materialize(children, elem, null, parentComponent);                                                 // 403
                                                                                                        // 404
    insert(elem, parent, before);                                                                       // 405
  } else if (typeof node.instantiate === 'function') {                                                  // 406
    // component                                                                                        // 407
    var instance = UI.render(node, parentComponent);                                                    // 408
                                                                                                        // 409
    insert(instance.dom, parent, before);                                                               // 410
  } else if (node instanceof HTML.CharRef) {                                                            // 411
    insert(document.createTextNode(node.str), parent, before);                                          // 412
  } else if (node instanceof HTML.Comment) {                                                            // 413
    insert(document.createComment(node.sanitizedValue), parent, before);                                // 414
  } else if (node instanceof HTML.Raw) {                                                                // 415
    // Get an array of DOM nodes by using the browser's HTML parser                                     // 416
    // (like innerHTML).                                                                                // 417
    var htmlNodes = UI.DomBackend.parseHTML(node.value);                                                // 418
    for (var i = 0; i < htmlNodes.length; i++)                                                          // 419
      insert(htmlNodes[i], parent, before);                                                             // 420
  } else if (Package['html-tools'] && (node instanceof Package['html-tools'].HTMLTools.Special)) {      // 421
    throw new Error("Can't materialize Special tag, it's just an intermediate rep");                    // 422
  } else if (node instanceof UI.InTemplateScope) {                                                      // 423
    materialize(node.content, parent, before, node.parentPtr);                                          // 424
  } else {                                                                                              // 425
    // can't get here                                                                                   // 426
    throw new Error("Unexpected node in htmljs: " + node);                                              // 427
  }                                                                                                     // 428
};                                                                                                      // 429
                                                                                                        // 430
                                                                                                        // 431
                                                                                                        // 432
// XXX figure out the right names, and namespace, for these.                                            // 433
// for example, maybe some of them go in the HTML package.                                              // 434
UI.materialize = materialize;                                                                           // 435
                                                                                                        // 436
UI.body = UI.Component.extend({                                                                         // 437
  kind: 'body',                                                                                         // 438
  contentParts: [],                                                                                     // 439
  render: function () {                                                                                 // 440
    return this.contentParts;                                                                           // 441
  },                                                                                                    // 442
  // XXX revisit how body works.                                                                        // 443
  INSTANTIATED: false                                                                                   // 444
});                                                                                                     // 445
                                                                                                        // 446
UI.block = function (renderFunc) {                                                                      // 447
  return UI.Component.extend({ render: renderFunc });                                                   // 448
};                                                                                                      // 449
                                                                                                        // 450
UI.toHTML = function (content, parentComponent) {                                                       // 451
  return HTML.toHTML(content, parentComponent);                                                         // 452
};                                                                                                      // 453
                                                                                                        // 454
UI.toRawText = function (content, parentComponent) {                                                    // 455
  return HTML.toText(content, HTML.TEXTMODE.STRING, parentComponent);                                   // 456
};                                                                                                      // 457
                                                                                                        // 458
//////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                      //
// packages/ui/builtins.js                                                                              //
//                                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                        //
                                                                                                        // 1
UI.If = function (argFunc, contentBlock, elseContentBlock) {                                            // 2
  checkBlockHelperArguments('If', argFunc, contentBlock, elseContentBlock);                             // 3
                                                                                                        // 4
  return function () {                                                                                  // 5
    if (getCondition(argFunc))                                                                          // 6
      return contentBlock;                                                                              // 7
    else                                                                                                // 8
      return elseContentBlock || null;                                                                  // 9
  };                                                                                                    // 10
};                                                                                                      // 11
                                                                                                        // 12
                                                                                                        // 13
UI.Unless = function (argFunc, contentBlock, elseContentBlock) {                                        // 14
  checkBlockHelperArguments('Unless', argFunc, contentBlock, elseContentBlock);                         // 15
                                                                                                        // 16
  return function () {                                                                                  // 17
    if (! getCondition(argFunc))                                                                        // 18
      return contentBlock;                                                                              // 19
    else                                                                                                // 20
      return elseContentBlock || null;                                                                  // 21
  };                                                                                                    // 22
};                                                                                                      // 23
                                                                                                        // 24
// Returns true if `a` and `b` are `===`, unless they are of a mutable type.                            // 25
// (Because then, they may be equal references to an object that was mutated,                           // 26
// and we'll never know.  We save only a reference to the old object; we don't                          // 27
// do any deep-copying or diffing.)                                                                     // 28
var safeEquals = function (a, b) {                                                                      // 29
  if (a !== b)                                                                                          // 30
    return false;                                                                                       // 31
  else                                                                                                  // 32
    return ((!a) || (typeof a === 'number') || (typeof a === 'boolean') ||                              // 33
            (typeof a === 'string'));                                                                   // 34
};                                                                                                      // 35
                                                                                                        // 36
// Unlike Spacebars.With, there's no else case and no conditional logic.                                // 37
//                                                                                                      // 38
// We don't do any reactive emboxing of `argFunc` here; it should be done                               // 39
// by the caller if efficiency and/or number of calls to the data source                                // 40
// is important.                                                                                        // 41
UI.With = function (argFunc, contentBlock) {                                                            // 42
  checkBlockHelperArguments('With', argFunc, contentBlock);                                             // 43
                                                                                                        // 44
  var block = contentBlock;                                                                             // 45
  if ('data' in block) {                                                                                // 46
    // XXX TODO: get religion about where `data` property goes                                          // 47
    block = UI.block(function () {                                                                      // 48
      return contentBlock;                                                                              // 49
    });                                                                                                 // 50
  }                                                                                                     // 51
  block.data = UI.emboxValue(argFunc, safeEquals);                                                      // 52
                                                                                                        // 53
  return block;                                                                                         // 54
};                                                                                                      // 55
                                                                                                        // 56
UI.Each = function (argFunc, contentBlock, elseContentBlock) {                                          // 57
  checkBlockHelperArguments('Each', argFunc, contentBlock, elseContentBlock);                           // 58
                                                                                                        // 59
  return UI.EachImpl.extend({                                                                           // 60
    __sequence: argFunc,                                                                                // 61
    __content: contentBlock,                                                                            // 62
    __elseContent: elseContentBlock                                                                     // 63
  });                                                                                                   // 64
};                                                                                                      // 65
                                                                                                        // 66
var checkBlockHelperArguments = function (which, argFunc, contentBlock, elseContentBlock) {             // 67
  if (typeof argFunc !== 'function')                                                                    // 68
    throw new Error('First argument to ' + which + ' must be a function');                              // 69
  if (! UI.isComponent(contentBlock))                                                                   // 70
    throw new Error('Second argument to ' + which + ' must be a template or UI.block');                 // 71
  if (elseContentBlock && ! UI.isComponent(elseContentBlock))                                           // 72
    throw new Error('Third argument to ' + which + ' must be a template or UI.block if present');       // 73
};                                                                                                      // 74
                                                                                                        // 75
// Acts like `!! conditionFunc()` except:                                                               // 76
//                                                                                                      // 77
// - Empty array is considered falsy                                                                    // 78
// - The result is Deps.isolated (doesn't trigger invalidation                                          // 79
//   as long as the condition stays truthy or stays falsy                                               // 80
var getCondition = function (conditionFunc) {                                                           // 81
  return Deps.isolateValue(function () {                                                                // 82
    // `condition` is emboxed; it is always a function,                                                 // 83
    // and it only triggers invalidation if its return                                                  // 84
    // value actually changes.  We still need to isolate                                                // 85
    // the calculation of whether it is truthy or falsy                                                 // 86
    // in order to not re-render if it changes from one                                                 // 87
    // truthy or falsy value to another.                                                                // 88
    var cond = conditionFunc();                                                                         // 89
                                                                                                        // 90
    // empty arrays are treated as falsey values                                                        // 91
    if (cond instanceof Array && cond.length === 0)                                                     // 92
      return false;                                                                                     // 93
    else                                                                                                // 94
      return !! cond;                                                                                   // 95
  });                                                                                                   // 96
};                                                                                                      // 97
                                                                                                        // 98
//////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                      //
// packages/ui/each.js                                                                                  //
//                                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                        //
UI.EachImpl = Component.extend({                                                                        // 1
  typeName: 'Each',                                                                                     // 2
  render: function (modeHint) {                                                                         // 3
    var self = this;                                                                                    // 4
    var content = self.__content;                                                                       // 5
    var elseContent = self.__elseContent;                                                               // 6
                                                                                                        // 7
    if (modeHint === 'STATIC') {                                                                        // 8
      // This is a hack.  The caller gives us a hint if the                                             // 9
      // value we return will be static (in HTML or text)                                               // 10
      // or dynamic (materialized DOM).  The dynamic path                                               // 11
      // returns `null` and then we populate the DOM from                                               // 12
      // the `parented` callback.                                                                       // 13
      //                                                                                                // 14
      // It would be much cleaner to always return the same                                             // 15
      // value here, and to have that value be some special                                             // 16
      // object that encapsulates the logic for populating                                              // 17
      // the #each using a mode-agnostic interface that                                                 // 18
      // works for HTML, text, and DOM.  Alternatively, we                                              // 19
      // could formalize the current pattern, e.g. defining                                             // 20
      // a method like component.populate(domRange) and one                                             // 21
      // like renderStatic() or even renderHTML / renderText.                                           // 22
      var parts = _.map(                                                                                // 23
        ObserveSequence.fetch(self.__sequence()),                                                       // 24
        function (item) {                                                                               // 25
          return content.extend({data: function () {                                                    // 26
            return item;                                                                                // 27
          }});                                                                                          // 28
        });                                                                                             // 29
                                                                                                        // 30
      if (parts.length) {                                                                               // 31
        return parts;                                                                                   // 32
      } else {                                                                                          // 33
        return elseContent;                                                                             // 34
      }                                                                                                 // 35
      return parts;                                                                                     // 36
    } else {                                                                                            // 37
      return null;                                                                                      // 38
    }                                                                                                   // 39
  },                                                                                                    // 40
  parented: function () {                                                                               // 41
    var self = this.__component__;                                                                      // 42
                                                                                                        // 43
    var range = self.dom;                                                                               // 44
                                                                                                        // 45
    var content = self.__content;                                                                       // 46
    var elseContent = self.__elseContent;                                                               // 47
                                                                                                        // 48
    // if there is an else clause, keep track of the number of                                          // 49
    // rendered items.  use this to display the else clause when count                                  // 50
    // becomes zero, and remove it when count becomes positive.                                         // 51
    var itemCount = 0;                                                                                  // 52
    var addToCount = function(delta) {                                                                  // 53
      if (!elseContent) // if no else, no need to keep track of count                                   // 54
        return;                                                                                         // 55
                                                                                                        // 56
      if (itemCount + delta < 0)                                                                        // 57
        throw new Error("count should never become negative");                                          // 58
                                                                                                        // 59
      if (itemCount === 0) {                                                                            // 60
        // remove else clause                                                                           // 61
        range.removeAll();                                                                              // 62
      }                                                                                                 // 63
      itemCount += delta;                                                                               // 64
      if (itemCount === 0) {                                                                            // 65
        UI.materialize(elseContent, range, null, self);                                                 // 66
      }                                                                                                 // 67
    };                                                                                                  // 68
                                                                                                        // 69
    this.observeHandle = ObserveSequence.observe(function () {                                          // 70
      return self.__sequence();                                                                         // 71
    }, {                                                                                                // 72
      addedAt: function (id, item, i, beforeId) {                                                       // 73
        addToCount(1);                                                                                  // 74
        id = LocalCollection._idStringify(id);                                                          // 75
                                                                                                        // 76
        var data = item;                                                                                // 77
        var dep = new Deps.Dependency;                                                                  // 78
                                                                                                        // 79
        // function to become `comp.data`                                                               // 80
        var dataFunc = function () {                                                                    // 81
          dep.depend();                                                                                 // 82
          return data;                                                                                  // 83
        };                                                                                              // 84
        // Storing `$set` on `comp.data` lets us                                                        // 85
        // access it from `changed`.                                                                    // 86
        dataFunc.$set = function (v) {                                                                  // 87
          data = v;                                                                                     // 88
          dep.changed();                                                                                // 89
        };                                                                                              // 90
                                                                                                        // 91
        if (beforeId)                                                                                   // 92
          beforeId = LocalCollection._idStringify(beforeId);                                            // 93
                                                                                                        // 94
        var renderedItem = UI.render(content.extend({data: dataFunc}), self);                           // 95
        range.add(id, renderedItem.dom, beforeId);                                                      // 96
      },                                                                                                // 97
      removed: function (id, item) {                                                                    // 98
        addToCount(-1);                                                                                 // 99
        range.remove(LocalCollection._idStringify(id));                                                 // 100
      },                                                                                                // 101
      movedTo: function (id, item, i, j, beforeId) {                                                    // 102
        range.moveBefore(                                                                               // 103
          LocalCollection._idStringify(id),                                                             // 104
          beforeId && LocalCollection._idStringify(beforeId));                                          // 105
      },                                                                                                // 106
      changed: function (id, newItem) {                                                                 // 107
        range.get(LocalCollection._idStringify(id)).component.data.$set(newItem);                       // 108
      }                                                                                                 // 109
    });                                                                                                 // 110
                                                                                                        // 111
    // on initial render, display the else clause if no items                                           // 112
    addToCount(0);                                                                                      // 113
  },                                                                                                    // 114
  destroyed: function () {                                                                              // 115
    if (this.observeHandle)                                                                             // 116
      this.observeHandle.stop();                                                                        // 117
  }                                                                                                     // 118
});                                                                                                     // 119
                                                                                                        // 120
//////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                      //
// packages/ui/fields.js                                                                                //
//                                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                        //
                                                                                                        // 1
var global = (function () { return this; })();                                                          // 2
                                                                                                        // 3
// Searches for the given property in `comp` or a parent,                                               // 4
// and returns it as is (without call it if it's a function).                                           // 5
var lookupComponentProp = function (comp, prop) {                                                       // 6
  comp = findComponentWithProp(prop, comp);                                                             // 7
  var result = (comp ? comp.data : null);                                                               // 8
  if (typeof result === 'function')                                                                     // 9
    result = _.bind(result, comp);                                                                      // 10
  return result;                                                                                        // 11
};                                                                                                      // 12
                                                                                                        // 13
// Component that's a no-op when used as a block helper like                                            // 14
// `{{#foo}}...{{/foo}}`. Prints a warning that it is deprecated.                                       // 15
var noOpComponent = function (name) {                                                                   // 16
  return Component.extend({                                                                             // 17
    kind: 'NoOp',                                                                                       // 18
    render: function () {                                                                               // 19
      Meteor._debug("{{#" + name + "}} is now unnecessary and deprecated.");                            // 20
      return this.__content;                                                                            // 21
    }                                                                                                   // 22
  });                                                                                                   // 23
};                                                                                                      // 24
                                                                                                        // 25
// This map is searched first when you do something like `{{#foo}}` in                                  // 26
// a template.                                                                                          // 27
var builtInComponents = {                                                                               // 28
  // for past compat:                                                                                   // 29
  'constant': noOpComponent("constant"),                                                                // 30
  'isolate': noOpComponent("isolate")                                                                   // 31
};                                                                                                      // 32
                                                                                                        // 33
_extend(UI.Component, {                                                                                 // 34
  // Options:                                                                                           // 35
  //                                                                                                    // 36
  // - template {Boolean} If true, look at the list of templates after                                  // 37
  //   helpers and before data context.                                                                 // 38
  lookup: function (id, opts) {                                                                         // 39
    var self = this;                                                                                    // 40
    var template = opts && opts.template;                                                               // 41
    var result;                                                                                         // 42
    var comp;                                                                                           // 43
                                                                                                        // 44
    if (!id)                                                                                            // 45
      throw new Error("must pass id to lookup");                                                        // 46
                                                                                                        // 47
    if (/^\./.test(id)) {                                                                               // 48
      // starts with a dot. must be a series of dots which maps to an                                   // 49
      // ancestor of the appropriate height.                                                            // 50
      if (!/^(\.)+$/.test(id)) {                                                                        // 51
        throw new Error("id starting with dot must be a series of dots");                               // 52
      }                                                                                                 // 53
                                                                                                        // 54
      var compWithData = findComponentWithProp('data', self);                                           // 55
      for (var i = 1; i < id.length; i++) {                                                             // 56
        compWithData = compWithData ? findComponentWithProp('data', compWithData.parent) : null;        // 57
      }                                                                                                 // 58
                                                                                                        // 59
      return (compWithData ? compWithData.data : null);                                                 // 60
                                                                                                        // 61
    } else if ((comp = findComponentWithProp(id, self))) {                                              // 62
      // found a property or method of a component                                                      // 63
      // (`self` or one of its ancestors)                                                               // 64
      var result = comp[id];                                                                            // 65
                                                                                                        // 66
    } else if (_.has(builtInComponents, id)) {                                                          // 67
      return builtInComponents[id];                                                                     // 68
                                                                                                        // 69
    // Code to search the global namespace for capitalized names                                        // 70
    // like component classes, `Template`, `StringUtils.foo`,                                           // 71
    // etc.                                                                                             // 72
    //                                                                                                  // 73
    // } else if (/^[A-Z]/.test(id) && (id in global)) {                                                // 74
    //   // Only look for a global identifier if `id` is                                                // 75
    //   // capitalized.  This avoids having `{{name}}` mean                                            // 76
    //   // `window.name`.                                                                              // 77
    //   result = global[id];                                                                           // 78
    //   return function (/*arguments*/) {                                                              // 79
    //     var data = getComponentData(self);                                                           // 80
    //     if (typeof result === 'function')                                                            // 81
    //       return result.apply(data, arguments);                                                      // 82
    //     return result;                                                                               // 83
    //   };                                                                                             // 84
    } else if (template && _.has(Template, id)) {                                                       // 85
      return Template[id];                                                                              // 86
                                                                                                        // 87
    } else if (Handlebars._globalHelpers[id]) {                                                         // 88
      // Backwards compatibility for helpers defined with                                               // 89
      // `Handlebars.registerHelper`. XXX what is the future pattern                                    // 90
      // for this? We should definitely not put it on the Handlebars                                    // 91
      // namespace.                                                                                     // 92
      result = Handlebars._globalHelpers[id];                                                           // 93
                                                                                                        // 94
    } else {                                                                                            // 95
      // Resolve id `foo` as `data.foo` (with a "soft dot").                                            // 96
      return function (/*arguments*/) {                                                                 // 97
        var data = getComponentData(self);                                                              // 98
        if (template && !(data && _.has(data, id)))                                                     // 99
          throw new Error("Can't find template, helper or data context key: " + id);                    // 100
        if (! data)                                                                                     // 101
          return data;                                                                                  // 102
        var result = data[id];                                                                          // 103
        if (typeof result === 'function')                                                               // 104
          return result.apply(data, arguments);                                                         // 105
        return result;                                                                                  // 106
      };                                                                                                // 107
    }                                                                                                   // 108
                                                                                                        // 109
    if (typeof result === 'function' && ! result._isEmboxedConstant) {                                  // 110
      // Wrap the function `result`, binding `this` to `getComponentData(self)`.                        // 111
      // This creates a dependency when the result function is called.                                  // 112
      // Don't do this if the function is really just an emboxed constant.                              // 113
      return function (/*arguments*/) {                                                                 // 114
        var data = getComponentData(self);                                                              // 115
        return result.apply(data, arguments);                                                           // 116
      };                                                                                                // 117
    } else {                                                                                            // 118
      return result;                                                                                    // 119
    };                                                                                                  // 120
  },                                                                                                    // 121
  lookupTemplate: function (id) {                                                                       // 122
    return this.lookup(id, {template: true});                                                           // 123
  },                                                                                                    // 124
  get: function (id) {                                                                                  // 125
    // support `this.get()` to get the data context.                                                    // 126
    if (id === undefined)                                                                               // 127
      id = ".";                                                                                         // 128
                                                                                                        // 129
    var result = this.lookup(id);                                                                       // 130
    return (typeof result === 'function' ? result() : result);                                          // 131
  },                                                                                                    // 132
  set: function (id, value) {                                                                           // 133
    var comp = findComponentWithProp(id, this);                                                         // 134
    if (! comp || ! comp[id])                                                                           // 135
      throw new Error("Can't find field: " + id);                                                       // 136
    if (typeof comp[id] !== 'function')                                                                 // 137
      throw new Error("Not a settable field: " + id);                                                   // 138
    comp[id](value);                                                                                    // 139
  }                                                                                                     // 140
});                                                                                                     // 141
                                                                                                        // 142
//////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                      //
// packages/ui/handlebars_backcompat.js                                                                 //
//                                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                        //
Handlebars = {                                                                                          // 1
  _globalHelpers: {},                                                                                   // 2
                                                                                                        // 3
  registerHelper: function (name, func) {                                                               // 4
    this._globalHelpers[name] = func;                                                                   // 5
  }                                                                                                     // 6
};                                                                                                      // 7
                                                                                                        // 8
// Utility to HTML-escape a string.                                                                     // 9
Handlebars._escape = (function() {                                                                      // 10
  var escape_map = {                                                                                    // 11
    "<": "&lt;",                                                                                        // 12
    ">": "&gt;",                                                                                        // 13
    '"': "&quot;",                                                                                      // 14
    "'": "&#x27;",                                                                                      // 15
    "`": "&#x60;", /* IE allows backtick-delimited attributes?? */                                      // 16
    "&": "&amp;"                                                                                        // 17
  };                                                                                                    // 18
  var escape_one = function(c) {                                                                        // 19
    return escape_map[c];                                                                               // 20
  };                                                                                                    // 21
                                                                                                        // 22
  return function (x) {                                                                                 // 23
    return x.replace(/[&<>"'`]/g, escape_one);                                                          // 24
  };                                                                                                    // 25
})();                                                                                                   // 26
                                                                                                        // 27
// Return these from {{...}} helpers to achieve the same as returning                                   // 28
// strings from {{{...}}} helpers                                                                       // 29
Handlebars.SafeString = function(string) {                                                              // 30
  this.string = string;                                                                                 // 31
};                                                                                                      // 32
Handlebars.SafeString.prototype.toString = function() {                                                 // 33
  return this.string.toString();                                                                        // 34
};                                                                                                      // 35
                                                                                                        // 36
//////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package.ui = {
  UI: UI,
  Handlebars: Handlebars
};

})();
